#version 330 core
/*
 *  Simple fragment sharder for example five
 */

uniform vec4 colour;

void main() {

	gl_FragColor = colour;

}